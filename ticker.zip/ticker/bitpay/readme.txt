To Understand All these tickers you should have a basic understanding 
of PHP and Json...

==================================================================

These are Just Simple to Understand just replace the Currency code and
You will get the price. Bitpay accepts a lot of country's currency but 
it offers very less details sorry but its all i can do.

Check Out My Examples to get a basic idea.

==================================================================

Enjoy !! And Dont Forget To Subscribe my CHannel for more

--------------------------------------------------------------
http://www.youtube.com/channel/UCo-j0bGZocOkrOVh32_jIhw
-----------------------------------------------------------

===================================================
Thank You :)