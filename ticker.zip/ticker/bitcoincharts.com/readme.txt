To Understand All these tickers you should have a basic understanding of C Programming...

==================================================================
Just

http://api.bitcoincharts.com/v1/markets.json

go here and Choose Your Desired Symbol and place it into 
the ticker and it will fetch its price again and again.

==================================================================

Enjoy !! And Dont Forget To Subscribe my CHannel for more

--------------------------------------------------------------
http://www.youtube.com/channel/UCo-j0bGZocOkrOVh32_jIhw
-----------------------------------------------------------

===================================================
Thank You :)