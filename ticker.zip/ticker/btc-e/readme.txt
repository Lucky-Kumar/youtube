To Understand All these tickers you should have a basic understanding 
of PHP and Json...

==================================================================
Just

replace the ***** with your desired Currency or altcoins but it should be in
pair like btc_usd or eur_rur.

https://btc-e.com/api/2/*******/ticker

Check Out My Examples to get a basic idea.

==================================================================

Enjoy !! And Dont Forget To Subscribe my CHannel for more

--------------------------------------------------------------
http://www.youtube.com/channel/UCo-j0bGZocOkrOVh32_jIhw
-----------------------------------------------------------

===================================================
Thank You :)